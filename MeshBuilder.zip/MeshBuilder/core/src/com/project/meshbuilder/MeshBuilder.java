package com.project.meshbuilder;

import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.model.Node;
import java.util.ArrayList;

public class MeshBuilder{
    private Model model;
    private double xSize;
    private double ySize;

    public MeshBuilder(String _function, double _xSize, double _ySize){
        xSize = _xSize;
        ySize = _ySize;

        ModelBuilder modelBuilder = new ModelBuilder();
        modelBuilder.begin();
        ArrayList<Node> nodes = new ArrayList<>();
        for(double i = (0 - 0.5 * ySize); i <= (0 + .5 * ySize); i += 0.01){
            for(double j = (0 - 0.5 * xSize); j <= (0 + .5 * xSize); j += 0.01){
                nodes.add(modelBuilder.node());
                nodes.get(nodes.size() - 1).id = "node" + (nodes.size() - 1);
                nodes.get(nodes.size() - 1).translation.set((float) j,(float) i,(float) function(j,i));
            }
        }
        model = modelBuilder.end();
    }

    private double function(double x, double y){
        double z = Math.cos(x) + Math.cos(y);
        return z;
    }

    public Model getModel(){
        return model;
    }
}
