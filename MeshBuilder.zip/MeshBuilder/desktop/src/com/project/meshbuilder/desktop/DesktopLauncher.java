package com.project.meshbuilder.desktop;

import com.project.meshbuilder.MeshBuilder;
import com.badlogic.gdx.graphics.g3d.Model;

public class DesktopLauncher {
	public static void main (String[] arg) {
		MeshBuilder meshBuilder = new MeshBuilder("f",20,20);
		Model terrain = meshBuilder.getModel();
	}
}
